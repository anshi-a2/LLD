package com.vending.machine.Enums;

public enum MachineStateType {
    IDLE,
    HAS_MONEY,
    DISPENSING
}

